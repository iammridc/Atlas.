import 'package:atlas/core/errors/app_exception.dart';
import 'package:atlas/features/home/domain/entity/recommendation_entity.dart';
import 'package:atlas/features/home/domain/entity/search_places_filter_entity.dart';
import 'package:dartz/dartz.dart';

abstract class RecommendationsRepository {
  Future<Either<AppException, List<RecommendationEntity>>> getRecommendations(
    List<String> categoryTypes,
  );

  Future<void> syncCurrentUserFavoritesToHotPlaces();

  Future<Either<AppException, List<RecommendationEntity>>> getHotPlaces();

  Future<Either<AppException, List<RecommendationEntity>>> searchPlaces(
    String query, {
    SearchPlacesFilterEntity filters = SearchPlacesFilterEntity.empty,
  });
}
